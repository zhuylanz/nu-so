let A = {
	a: 15,
}


let b = JSON.parse(JSON.stringify(A))
b.b = '16';


console.log(b)
console.log(A)