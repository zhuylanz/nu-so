const rp = require('request-promise');
const fs = require('fs');


let _login = async function(username, password) {
	let cookie = '';
	let option_probe = {
		method: 'GET',
		uri: 'https://www.facebook.com/',
		headers: {
			'accept-encoding': 'gzip, deflate',
			'accept-language': 'en-US,en;q=0.9',
			'upgrade-insecure-requests': '1',
			'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.146 Safari/537.36',
			'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
			'cache-control': 'max-age=0',
			'authority': 'www.facebook.com',
		},
		gzip: true,
		resolveWithFullResponse: true,
	}
	
	try {
		let res = await rp(option_probe);
		let cookie_chunk = 'datr='+res.body.match(/datr",".{24}/g)[0].slice(-24);

		let res_cookie = res.headers['set-cookie'];
		for (var i in res_cookie) {
			cookie += res_cookie[i].split(';')[0] + ';'
		}

		let option_login = {
			method: 'POST',
			uri: 'https://www.facebook.com/login.php?login_attempt=1&lwv=110',
			form: {
				lsd: '',
				email: username,
				pass: password,
				timezone: '-420',
				lgndim: '',
				lgnrnd: '',
				lgnjs: '',
				ab_test_data: '',
				locale: 'vi_VN',
				login_source: 'login_bluebar',
				prefill_contact_point: '',
				prefill_source: '',
				prefill_type: '',
				skstamp: ''
			},
			headers: {
				'cookie': cookie,
				'origin': 'https://www.facebook.com',
				'accept-encoding': 'gzip, deflate',
				'accept-language': 'en-US,en;q=0.9',
				'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.146 Safari/537.36',
				'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
				'accept': '*/*',
				'referer': 'https://www.facebook.com/',
				'authority': 'www.facebook.com',
				'x-requested-with': 'XMLHttpRequest',
			},
			gzip: true
		}

		try {
			res = await rp(option_login);
		} catch(err) {
			res_cookie = err.response.headers['set-cookie'];
			cookie = '';
			for (var i in res_cookie) {
				cookie += res_cookie[i].split(';')[0] + ';'
			}
			cookie += cookie_chunk;
		}


		let uid = cookie.match(/c_user=\d*/g);
		if (uid) {
			uid = uid[0].substr(7);
		} else {
			throw 'Authentication Error: wrong login credential?';
		}
		return {
			profile_id: uid,
			cookie: cookie
		};

	} catch(err) {
		console.log(err);
	}
}

let _getLogined = async function(cookie) {
	let option = {
		method: 'GET',
		uri: 'https://www.facebook.com/',
		headers: {
			'accept-encoding': 'gzip',
			'cookie': cookie,
			'accept-language': 'en-US,en;q=0.9',
			'upgrade-insecure-requests': '1',
			'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.146 Safari/537.36',
			'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
			'cache-control': 'max-age=0',
			'authority': 'www.facebook.com',
			'origin': 'https://www.facebook.com'
		},
		json: true,
		gzip: true
	}

	try {
		let res = await rp(option);

		let dyna_key = {
			fb_dtsg: res.match(/value=".{12}:.{12}/g)[0].slice(7),
			__rev: res.match(/client_revision":\d{7}/g)[0].slice(17),
			__dyn: '',
			jazoest: '',
			__spin_t: Math.floor(Date.now() / 1000),
		}

		dyna_key.__spin_r = dyna_key.__rev;
		for (var x = 0; x < dyna_key.fb_dtsg.length; x++) {
			dyna_key.jazoest += dyna_key.fb_dtsg.charCodeAt(x);
		}
		dyna_key.jazoest = '2' + dyna_key.jazoest;

		return dyna_key;

	} catch(err) {
		console.log('authentication failure: ' + err);
	}

}

let Profile = function(username, password, credential) {
	this.login = async function(m) {
		if (m == 1) {
			this.dyna_key = await _getLogined(this.credential.cookie);
		} else {
			this.credential = await _login(username, password);
			this.dyna_key = await _getLogined(this.credential.cookie);
		}

		this.headers = {
			'accept-encoding': 'gzip, deflate, br',
			'cookie': this.credential.cookie,
			'accept-language': 'en-US,en;q=0.9',
			'upgrade-insecure-requests': '1',
			'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
			'accept': '*/*',
			'authority': 'www.facebook.com',
			'x-requested-with': 'XMLHttpRequest',
			'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.146 Safari/537.36',
			'origin': 'https://www.facebook.com'
		}

		this.form = {
			__user: this.credential.profile_id,
			__a: '1',
			__dyn: this.dyna_key.__dyn,
			__req: '3d',
			__be: '1',
			__pc: 'PHASED:DEFAULT',
			__rev: this.dyna_key.__rev,
			fb_dtsg: this.dyna_key.fb_dtsg,
			jazoest: this.dyna_key.jazoest,
			__spin_r: this.dyna_key.__spin_r,
			__spin_b: 'trunk',
			__spin_t: this.dyna_key.__spin_t,
		}

		return this;
	}

	this.waitForDyna = async function() {
		if (!this.dyna_key) {
			if (!credential) {
				return this.login();
			} else {
				this.credential = credential;
				return this.login(1);
			}
		}
	}

	this.unfriend = async function(uid) {
		let form = JSON.parse(JSON.stringify(this.form));
		form.uid = uid; form.unref = 'bd_profile_button'; form.floc = 'profile_button';

		let option = {
			method: 'POST',
			uri: 'https://www.facebook.com/ajax/profile/removefriendconfirm.php?dpr=1',
			form: form,
			headers: this.headers,
			gzip: true
		}
		console.log(option.form);

		try {
			return rp(option);
		} catch(e) {
			throw e
		}
	}

	this.postToFriend = async function(uid, content) {
		let form = JSON.parse(JSON.stringify(this.form));
		form.variables = '{"client_mutation_id":"ec4cf7c9-9cd2-404f-a6d2-75bf36de75cc","actor_id":"'+this.credential.profile_id+'","input":{"actor_id":"'+this.credential.profile_id+'","client_mutation_id":"df783954-dc35-4a0e-a85b-514e9bd5d714","source":"WWW","audience":{"to_id":"'+uid+'"},"message":{"text":"'+content+'","ranges":[]},"logging":{"composer_session_id":"ec8570e5-d00d-492a-b4ee-b75cf9127ce5","ref":"timeline"},"with_tags_ids":[],"multilingual_translations":[],"composer_source_surface":"timeline","composer_entry_time":-1,"composer_session_events_log":{"composition_duration":57,"number_of_keystrokes":62},"direct_share_status":"NOT_SHARED","sponsor_relationship":"WITH","web_graphml_migration_params":{"target_type":"wall","xhpc_composerid":"rc.u_ps_fetchstream_1_2_1","xhpc_context":"profile","xhpc_publish_type":"FEED_INSERT","xhpc_timeline":true},"extensible_sprouts_ranker_request":{"RequestID":"ZvBXCwABAAAAJDYxMGUyYjZhLWQ3ZTUtNDIzOC1lMmE3LTRjNzIxNjY2ZjdjNwoAAgAAAABantyLCwADAAAABFNFTEwGAAQADgsABQAAABhVTkRJUkVDVEVEX0ZFRURfQ09NUE9TRVIA"},"place_attachment_setting":"HIDE_ATTACHMENT"}}';

		let option = {
			method: 'POST',
			uri: 'https://www.facebook.com/webgraphql/mutation/?doc_id=1931212663571278&dpr=1',
			form: form,
			headers: this.headers,
			gzip: true
		}
		console.log(option.form);

		try {
			return rp(option);
		} catch(e) {
			throw e
		}
	}

	this._goTo = async function(uri) {

	}
	


	//main
	return this.waitForDyna();
}



async function test() {
	new Profile('zhuylanz20@gmail.com', 'iamarobot').then(acc => {
		acc.postToFriend('100018380588332', 'Ngủ ngon nha!! <3').then(res => {
			acc.unfriend('100016593342175');
		}).catch(err => console.log(err));
	}).catch(err => console.log(err));

}

test();